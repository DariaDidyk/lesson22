class Cross {
  constructor() {
    this.el = document.createElement('div');
    this.init();
  }

  init() {
    this.el.innerHTML = 'X';
  }
}
